const fuzzy_search_collection_by_field = async (collection, query, field) => {
  return await collection.aggregate([
        {
            "$search": {
                "text": {
                    "query": query,
                    "path": "name",
                    "fuzzy": {
                        "maxEdits": 2,
                        "prefixLength": 2
                    }
                }
            }
        }
    ]).toArray();
}

exports = async (query, limit = 12) => {
    const cluster = context.services.get("mongodb-atlas");
    const products = cluster.db("mongoshop").collection("products");
    const matching_name = await fuzzy_search_collection_by_field(products, query, 'name')
    const matching_brand = await fuzzy_search_collection_by_field(products, query, 'brand')
    return matching_name.concat(matching_brand).slice(0, limit)
};